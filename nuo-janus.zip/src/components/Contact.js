import React from "react";

const Contact = ()=> {

    return (

        <h2>LOVE</h2>
    )
}

export default Contact;