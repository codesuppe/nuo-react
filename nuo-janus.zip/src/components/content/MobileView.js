import React from "react";


const MobileView = ({ items }) => { 

    return (
        <h2> hello</h2>
    )
};

export default MobileView;
