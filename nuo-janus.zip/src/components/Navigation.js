import React from "react";
import { Link } from "react-router-dom";

const Navigation = (desktopdata) => {
    
  return (
    <div id="navigation">
      <nav>
        <Link to="/">
          <img src= {desktopdata.images.navImages[0]} alt="nav-1"/>
        </Link>

        <Link to="/about">
          Hi bro
        </Link>

        <Link to="/contact"></Link>
      </nav>
    </div>
  );
  
};
export default Navigation;
