import React from "react";

const About = ()=>{
    return (

        <h2>ABOUT</h2>
    )
}

export default About;